const db = require('../models/database');

exports.signup = (req, res) => {
  const { username, password } = req.body;
  db.run("INSERT INTO users (username, password) VALUES (?, ?)", [username, password], (err) => {
    if (err) return res.send("User already exists.");
    res.redirect('/login');
  });
};

exports.login = (req, res) => {
  const { username, password } = req.body;
  db.get("SELECT * FROM users WHERE username = ? AND password = ?", [username, password], (err, user) => {
    if (!user) return res.send("Invalid credentials.");
    req.session.user = user;
    res.redirect('/');
  });
};

exports.logout = (req, res) => {
  req.session.destroy();
  res.redirect('/');
};