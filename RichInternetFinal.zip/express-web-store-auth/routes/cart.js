const express = require('express');
const router = express.Router();

// GET /cart — Show user's cart
router.get('/', (req, res) => {
  const cart = req.session.cart || [];  // Use session cart instead of hardcoded data
  res.render('cart', {
    title: 'Shopping Cart',
    cart
  });
});

module.exports = router;
