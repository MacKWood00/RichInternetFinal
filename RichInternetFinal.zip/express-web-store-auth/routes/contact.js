const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.render('contact', { title: 'Contact Us' });
});

router.post('/', (req, res) => {
  const { name, email, message } = req.body;

  console.log('Contact form submitted:', { name, email, message });

  // Simulate success for now
  res.render('contact', { title: 'Contact Us', success: true });
});

module.exports = router;
