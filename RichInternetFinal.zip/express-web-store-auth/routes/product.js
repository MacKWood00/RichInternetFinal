const express = require('express');
const router = express.Router();
const productsData = require('../data/product.json');


// Mock product data
const products = [
  { id: 1, name: 'Hoodie', description: 'Cozy cotton hoodie', price: 29.99 },
  { id: 2, name: 'Sneakers', description: 'Running shoes', price: 59.99 },
  { id: 3, name: 'Jacket', description: 'Windbreaker jacket', price: 49.99 }
];

// 🔁 Add to Cart FIRST — important for route matching
router.post('/add-to-cart/:id', (req, res) => {
  const productId = parseInt(req.params.id);
  const product = products.find(p => p.id === productId);

  if (!product) {
    return res.status(404).send('Product not found');
  }

  if (!req.session.cart) {
    req.session.cart = [];
  }

  const existingItem = req.session.cart.find(item => item.id === product.id);
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    req.session.cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images && product.images[0] ? product.images[0] : null,
      quantity: 1
    });
  }

  console.log('Cart:', req.session.cart);
  res.redirect('/cart');
});

// 📄 Route to display all products
router.get('/', (req, res) => {
  res.render('products', { title: 'Product Listings',products: productsData.products });
});

router.get('/list', (req, res) => {
  res.render('product-list', {
    title: 'Product List',
    products: productsData.products
  });
});


// 📄 Route to display one product by ID
router.get('/:id', (req, res) => {
  const productId = parseInt(req.params.id);
  const product = products.find(p => p.id === productId);

  if (!product) {
    return res.status(404).send('Product not found');
  }

  res.render('product', { product });
});

module.exports = router;
