const express = require('express');
const router = express.Router();

// Login Page
router.get('/login', (req, res) => {
  res.render('login', { title: 'Login' });
});

// Login Logic (Mock)
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  const mockUsers = [
    { id: 1, username: 'admin', password: 'admin123' },
    { id: 2, username: 'test', password: 'test123' }
  ];

  const user = mockUsers.find(u => u.username === username);

  if (user && user.password === password) {
    req.session.user = { id: user.id, username: user.username };
    res.redirect('/cart');
  } else {
    res.redirect('/auth/login');
  }
});

// Signup Page
router.get('/signup', (req, res) => {
  res.render('signup', { title: 'Signup' });
});

// Signup Logic (Mock)
router.post('/signup', (req, res) => {
  const { username, password } = req.body;

  console.log('Mock signup request:', { username, password });

  // Simulate user creation
  req.session.user = {
    id: Date.now(), // fake ID
    username
  };

  res.redirect('/cart');
});

module.exports = router;
