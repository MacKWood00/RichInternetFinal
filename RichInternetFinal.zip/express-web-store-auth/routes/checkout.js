const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const cart = req.session.cart || []; // ✅ fix: get cart from session
  res.render('checkout', {
    title: 'Checkout',
    cart
  });
});

router.post('/', (req, res) => {
  req.session.cart = []; // clear cart
  res.redirect('/order-complete'); // show confirmation
});


module.exports = router;
