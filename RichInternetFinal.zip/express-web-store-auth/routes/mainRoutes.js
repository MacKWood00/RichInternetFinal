const express = require('express');
const router = express.Router();
const db = require('../models/database');

router.get('/', (req, res) => res.render('index'));
router.get('/men', (req, res) => {
    db.all("SELECT * FROM products WHERE category = 'men'", [], (err, products) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }
      res.render('men', { products });
    });
  });
router.get('/women', (req, res) => res.render('women'));
router.get('/kids', (req, res) => res.render('kids'));

module.exports = router;
