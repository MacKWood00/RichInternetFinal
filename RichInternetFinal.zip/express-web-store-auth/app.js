require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');
//const { fileURLToPath } = require('url');
//const { dirname } = require('path');
const morgan = require('morgan');

// Define __dirname for ES Modules
//const __filename = fileURLToPath(import.meta.url);
//const __dirname = dirname(__filename);

// Import routes
const_dirname = path.resolve();

const join = path.join;
const aboutRoute = require('./routes/about');
const contactRoute = require('./routes/contact');
const productsRoute = require('./routes/product');
const cartRoute = require('./routes/cart');
const authRoute = require('./routes/auth');
const checkoutRoute = require('./routes/checkout');
const orderCompleteRoute = require('./routes/order-complete');


const app = express();

// Connect to MongoDB
//const MONGO_URI = 'mongodb://localhost:27017/personal-website';

//console.log('MongoDB URI:', process.env.MONGO_URI);

//connect(MONGO_URI)
  //.then(() => {
    //console.log('Connected to MongoDB');
 // })
  //.catch((err) => {
    //console.error('Failed to connect to MongoDB');
    //console.error('Error details:', err);
 // });

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'fallback-secret', // Use a fallback for development
  resave: false,
  saveUninitialized: true,
}));
app.use(morgan('dev'));

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Set EJS as the template engine
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'views'));

// Routes
console.log('Initializing routes...');
app.use('/about', aboutRoute);
app.use('/contact', contactRoute);
app.use('/products', productsRoute);
app.use('/cart', cartRoute);
app.use('/auth', authRoute);
app.use('/checkout', checkoutRoute);
app.use('/order-complete', orderCompleteRoute);
console.log('Routes initialized.');

// Home route
app.get('/', (_, res) => {
  res.redirect('/about');
});

// 404 handler
app.use((req, res) => {
  res.status(404).render('404', { title: 'Page Not Found' });
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});